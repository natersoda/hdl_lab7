blink_rom_inst : blink_rom PORT MAP (
      address     => address_sig,
      clock       => clk,
      q           => q_sig
  );
	  
