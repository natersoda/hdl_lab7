blink_rom_inst : blink_rom PORT MAP (
      address     => i,
      clock       => clk_50_mhz,
      q           => mem_curr
    );
	  
