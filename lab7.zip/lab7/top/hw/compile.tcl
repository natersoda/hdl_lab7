# Dr. Kaputa
# Quartus II compile script for DE1-SoC board

# 1] name your project here
set project_name "top"

file delete -force project
file delete -force output_files
file mkdir project
cd project
load_package flow
project_new $project_name
set_global_assignment -name FAMILY Cyclone
set_global_assignment -name DEVICE 5CSEMA5F31C6 
set_global_assignment -name TOP_LEVEL_ENTITY labseven
set_global_assignment -name PROJECT_OUTPUT_DIRECTORY ../output_files

# 2] include your relative path files here
set_global_assignment -name QIP_FILE ../../src/rom/blink_rom.qip
set_global_assignment -name VHDL_FILE ../../src/rising_edge_synchronizer.vhd
set_global_assignment -name VHDL_FILE ../../src/seven_seg.vhd
set_global_assignment -name VHDL_FILE ../../src/generic_adder_beh.vhd
set_global_assignment -name VHDL_FILE ../../src/synchronizer_nbit.vhd
set_global_assignment -name VHDL_FILE ../../src/alu.vhd
set_global_assignment -name VHDL_FILE ../../src/top.vhd
set_global_assignment -name VHDL_FILE ../../src/labseven.vhd

set_location_assignment PIN_AF14 -to clk_50_mhz

set_location_assignment PIN_V16  -to state_out[0]
set_location_assignment PIN_W16  -to state_out[1]
set_location_assignment PIN_V17  -to state_out[2]
set_location_assignment PIN_V18  -to state_out[3]

set_location_assignment PIN_AE26 -to hex2_out[0]
set_location_assignment PIN_AE27 -to hex2_out[1]
set_location_assignment PIN_AE28 -to hex2_out[2]
set_location_assignment PIN_AG27 -to hex2_out[3]
set_location_assignment PIN_AF28 -to hex2_out[4]
set_location_assignment PIN_AH28 -to hex2_out[6]
set_location_assignment PIN_AG28 -to hex2_out[5]

set_location_assignment PIN_AJ29 -to hex1_out[0]
set_location_assignment PIN_AH29 -to hex1_out[1]
set_location_assignment PIN_AH30 -to hex1_out[2]
set_location_assignment PIN_AG30 -to hex1_out[3]
set_location_assignment PIN_AF29 -to hex1_out[4]
set_location_assignment PIN_AF30 -to hex1_out[5]
set_location_assignment PIN_AD27 -to hex1_out[6]

set_location_assignment PIN_AB23 -to hex0_out[0]
set_location_assignment PIN_AE29 -to hex0_out[1]
set_location_assignment PIN_AD29 -to hex0_out[2]
set_location_assignment PIN_AC28 -to hex0_out[3]
set_location_assignment PIN_AD30 -to hex0_out[4]
set_location_assignment PIN_AC29 -to hex0_out[5]
set_location_assignment PIN_AC30 -to hex0_out[6]

set_location_assignment PIN_AA14 -to pb
set_location_assignment PIN_Y16 -to reset


execute_flow -compile
project_close