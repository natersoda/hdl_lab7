-------------------------------------------------------------------------------
-- nate ralston
-- lab7 labseven test bench (self-checking)
--
-- Drives labseven the way the DE1-SoC board does:
--   * KEY buttons are active low, so reset and pb idle at '1' and the design
--     reacts on the RELEASE (rising edge) of each button
--   * presses reset once, then presses pb NUM_PRESSES times
--   * after each press it waits for the pipeline to settle, then checks the
--     LEDs (state_out) and the 3-digit 7-seg display against what blink.mif
--     should produce
--
-- Expected result for the current blink.mif (every opcode = 00 = add):
--   address n holds the value n for n = 0..9 and 1 for n = 10..31
--   the wrapper increments the address BEFORE top executes, so press n uses
--   address n and the display shows a running total:
--   1, 3, 6, 10, 15, 21, 28, 36, 45, 46, 47, ...
-- If you change blink.mif, update rom_word() below.
--
-- Display digit order (from top.vhd):  hex0 = hundreds, hex1 = tens, hex2 = ones
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity labseven_tb is
end labseven_tb;

architecture arch of labseven_tb is

component labseven is
  port (
    clk_50_mhz   : in  std_logic;
    reset        : in  std_logic;
    pb           : in  std_logic;
    state_out    : out std_logic_vector(3 downto 0);
    hex0_out     : out std_logic_vector(6 downto 0);
    hex1_out     : out std_logic_vector(6 downto 0);
    hex2_out     : out std_logic_vector(6 downto 0)
  );
end component;

constant period      : time    := 20 ns;   -- 50 MHz
constant NUM_PRESSES : integer := 14;      -- must stay below 32 (5-bit address)
constant HOLD_CLKS   : integer := 4;       -- clocks the button is held down
constant SETTLE_CLKS : integer := 40;      -- clocks to wait after releasing

signal clk_50_mhz : std_logic := '0';
signal reset      : std_logic := '1';
signal pb         : std_logic := '1';
signal state_out  : std_logic_vector(3 downto 0);
signal hex0_out   : std_logic_vector(6 downto 0);
signal hex1_out   : std_logic_vector(6 downto 0);
signal hex2_out   : std_logic_vector(6 downto 0);

-- 7-seg pattern -> digit (same patterns as seven_seg.vhd), -1 = not a digit
function decode_ssd (s : std_logic_vector(6 downto 0)) return integer is
begin
  case s is
    when "1000000" => return 0;
    when "1111001" => return 1;
    when "0100100" => return 2;
    when "0110000" => return 3;
    when "0011001" => return 4;
    when "0010010" => return 5;
    when "0000010" => return 6;
    when "1111000" => return 7;
    when "0000000" => return 8;
    when "0011000" => return 9;
    when others    => return -1;
  end case;
end function;

-- mirrors blink.mif: value stored at each address (opcode bits are all "00")
function rom_word (addr : integer) return integer is
begin
  if addr <= 9 then
    return addr;
  else
    return 1;
  end if;
end function;

-- one-hot LED pattern the state machine should show after n presses
function expected_state (n : integer) return std_logic_vector is
begin
  case (n mod 4) is
    when 0      => return "0001";
    when 1      => return "0010";
    when 2      => return "0100";
    when others => return "1000";
  end case;
end function;

function to_str (v : std_logic_vector) return string is
  variable r : string(1 to v'length);
  variable j : integer := 1;
begin
  for i in v'range loop
    case v(i) is
      when '0'    => r(j) := '0';
      when '1'    => r(j) := '1';
      when others => r(j) := 'X';
    end case;
    j := j + 1;
  end loop;
  return r;
end function;

begin

-- clock process
clk_50_mhz <= not clk_50_mhz after period/2;

-- device under test
uut: labseven
  port map(
    clk_50_mhz   => clk_50_mhz,
    reset        => reset,
    pb           => pb,
    state_out    => state_out,
    hex0_out     => hex0_out,
    hex1_out     => hex1_out,
    hex2_out     => hex2_out
  );

-- stimulus + checker
stimulus: process
  variable expected : integer := 0;
  variable d0, d1, d2 : integer;
  variable shown    : integer;
  variable errors   : integer := 0;
begin
  wait for 5 * period;

  -- press and release reset (design resets on the release)
  reset <= '0';
  wait for HOLD_CLKS * period;
  reset <= '1';
  wait for SETTLE_CLKS * period;

  for n in 1 to NUM_PRESSES loop
    -- press and release pb (design acts on the release)
    pb <= '0';
    wait for HOLD_CLKS * period;
    pb <= '1';
    wait for SETTLE_CLKS * period;

    -- what the display should show now
    expected := (expected + rom_word(n mod 32)) mod 256;

    d0 := decode_ssd(hex0_out);
    d1 := decode_ssd(hex1_out);
    d2 := decode_ssd(hex2_out);
    if (d0 < 0) or (d1 < 0) or (d2 < 0) then
      shown := -1;
    else
      shown := 100 * d0 + 10 * d1 + d2;
    end if;

    report "press " & integer'image(n) &
           ":  display = " & integer'image(shown) &
           "  expected = " & integer'image(expected) &
           "  state_out = " & to_str(state_out) &
           "  expected = " & to_str(expected_state(n));

    if shown /= expected then
      errors := errors + 1;
      report "MISMATCH on press " & integer'image(n) & ": display value is wrong"
        severity error;
    end if;
    if state_out /= expected_state(n) then
      errors := errors + 1;
      report "MISMATCH on press " & integer'image(n) & ": state_out is wrong"
        severity error;
    end if;
  end loop;

  if errors = 0 then
    report "TEST PASSED: all " & integer'image(NUM_PRESSES) & " presses matched"
      severity note;
  else
    report "TEST FAILED: " & integer'image(errors) & " mismatch(es)"
      severity error;
  end if;
  wait;
end process;

end arch;
