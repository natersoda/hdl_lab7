vlib work
vmap altera_mf ../../src/altera_mf
vcom -93 -work work ../../src/rom/blink_rom.vhd
vcom -93 -work work ../../src/rising_edge_synchronizer.vhd
vcom -93 -work work ../../src/synchronizer_nbit.vhd
vcom -93 -work work ../../src/alu.vhd
vcom -93 -work work ../../src/seven_seg.vhd
vcom -93 -work work ../../src/top.vhd
vcom -93 -work work ../../src/labseven.vhd
vcom -93 -work work ../src/labseven_tb.vhd
vsim -voptargs=+acc labseven_tb
do wave.do
run 20 us
