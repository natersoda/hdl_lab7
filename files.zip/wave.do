onerror {resume}
radix define SSD {
    "7'b1000000" "0" -color "orange",
    "7'b1111001" "1" -color "orange",
    "7'b0100100" "2" -color "orange",
    "7'b0110000" "3" -color "orange",
    "7'b0011001" "4" -color "orange",
    "7'b0010010" "5" -color "orange",
    "7'b0000010" "6" -color "orange",
    "7'b1111000" "7" -color "orange",
    "7'b0000000" "8" -color "orange",
    "7'b0011000" "9" -color "orange",
    -default default
}
quietly WaveActivateNextPane {} 0
add wave -noupdate -divider {inputs}
add wave -noupdate /labseven_tb/uut/clk_50_mhz
add wave -noupdate /labseven_tb/uut/reset
add wave -noupdate /labseven_tb/uut/pb
add wave -noupdate -divider {labseven wrapper (ROM side)}
add wave -noupdate /labseven_tb/uut/pb_s
add wave -noupdate -radix unsigned /labseven_tb/uut/i
add wave -noupdate -radix binary /labseven_tb/uut/mem_curr
add wave -noupdate /labseven_tb/uut/flagChange
add wave -noupdate /labseven_tb/uut/exe
add wave -noupdate -divider {top (math side)}
add wave -noupdate /labseven_tb/uut/lab6_uut/pb_s
add wave -noupdate /labseven_tb/uut/lab6_uut/stateReg
add wave -noupdate -radix binary /labseven_tb/state_out
add wave -noupdate -radix binary /labseven_tb/uut/lab6_uut/math_op_s
add wave -noupdate -radix unsigned /labseven_tb/uut/lab6_uut/sw_s
add wave -noupdate -radix unsigned /labseven_tb/uut/lab6_uut/mem_in
add wave -noupdate -radix unsigned /labseven_tb/uut/lab6_uut/displaysig
add wave -noupdate -radix unsigned /labseven_tb/uut/lab6_uut/mem_1
add wave -noupdate -radix unsigned /labseven_tb/uut/lab6_uut/mem_2
add wave -noupdate -radix unsigned /labseven_tb/uut/lab6_uut/mem_3
add wave -noupdate -radix unsigned /labseven_tb/uut/lab6_uut/mem_4
add wave -noupdate -divider {7-seg display (hex0 = hundreds, hex1 = tens, hex2 = ones)}
add wave -noupdate -radix SSD /labseven_tb/hex0_out
add wave -noupdate -radix SSD /labseven_tb/hex1_out
add wave -noupdate -radix SSD /labseven_tb/hex2_out
TreeUpdate [SetDefaultTree]
configure wave -namecolwidth 190
configure wave -valuecolwidth 70
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {0 ns} {14000 ns}
